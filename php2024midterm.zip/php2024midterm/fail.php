<html>

<meta charest="utf-8">

<?php
    echo "登入失敗! <br/>";
    echo "三秒之後回到登入頁面!";
    header("Refresh:3;url=index.php");
?>

</html>